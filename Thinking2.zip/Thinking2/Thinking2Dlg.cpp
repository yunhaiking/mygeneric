// Thinking2Dlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Thinking2.h"
#include "Thinking2Dlg.h"
#include "cderr.h"  //for definition of FNERR_BUFFERTOOSMALL
//#include <string>
//
//using std::string;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CThinking2Dlg �Ի���




CThinking2Dlg::CThinking2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CThinking2Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	//m_sumyitems.clear();
	//m_totalsumy.clear();
	m_bFileType = false;
	m_bRESSummary = false;
	m_bMergeSuccess = false;
	m_bFileError = false;
	m_hThread = NULL;
	//m_pCSummary = NULL;
}

void CThinking2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LT_FILES, m_listFiles);
}

BEGIN_MESSAGE_MAP(CThinking2Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_DISPOSE_END, DisposeEnd)
	ON_BN_CLICKED(IDC_BTN_LOADFILES, &CThinking2Dlg::OnBnClickedBtnLoadfiles)
	ON_BN_CLICKED(IDC_BTN_GENRT, &CThinking2Dlg::OnBnClickedBtnGenrt)
	ON_BN_CLICKED(IDC_BTN_CLR, &CThinking2Dlg::OnBnClickedBtnClr)
	ON_BN_CLICKED(IDC_RADIO_EAGLE, &CThinking2Dlg::OnBnClickedRadioEagle)
	ON_BN_CLICKED(IDC_RADIO_ACCO, &CThinking2Dlg::OnBnClickedRadioAcco)
	ON_NOTIFY(HDN_ITEMCLICK, 0, &CThinking2Dlg::OnHdnItemclickLtFiles)
END_MESSAGE_MAP()


// CThinking2Dlg ��Ϣ��������

BOOL CThinking2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���

	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	GetClientRect(&m_rect);

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_fontEdit.DeleteObject();
	m_fontEdit.CreatePointFont(120,_T("Arial"));
    ((CEdit*)GetDlgItem(IDC_ET_FILESPATH))->SetFont(&m_fontEdit);

	m_listFiles.SetTextColor(RGB (0, 0, 0));
	m_listFiles.SetTextBkColor(RGB (107, 198, 2));
	m_listFiles.SetBkColor(RGB (255, 255, 255));  

	m_listFiles.InsertColumn(0, _T("SN"));
	m_listFiles.InsertColumn(1, _T("Mark"));
	m_listFiles.InsertColumn(2, _T("File Name"));

	RECT rect;
	m_listFiles.GetWindowRect(&rect);
	int wid = rect.right - rect.left;
	m_listFiles.SetColumnWidth(0, 28);
	m_listFiles.SetColumnWidth(1, 36);
	m_listFiles.SetColumnWidth(2, 4*wid);
	m_listFiles.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

	//Eagle .txt file
	((CButton*)GetDlgItem(IDC_RADIO_EAGLE))->SetCheck(1);

	//m_pCSummary = new CSummary;

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CThinking2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CThinking2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CThinking2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CThinking2Dlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if (nType != SIZE_MINIMIZED)             //�жϴ����ǲ�����С���ˣ���Ϊ������С��֮�� �����ڵĳ��Ϳ�����0����ǰһ�α仯��ʱ�ͻ���ֳ���0�Ĵ������
	{
		ChangeSize(IDC_ET_FILESPATH,cx,cy);  //��ÿһ���ؼ�����������
		ChangeSize(IDC_BTN_LOADFILES,cx,cy);
		ChangeSize(IDC_BTN_GENRT,cx,cy);
		ChangeSize(IDC_BTN_CLR,cx,cy); 
		ChangeSize(IDC_LT_FILES,cx,cy); 
		//GetClientRect(&m_rect);              //���Ҫ���¶Ի���Ĵ�С��������һ�α仯�ľ����ꣻ
	}
}

void CThinking2Dlg::ChangeSize(UINT nID, int x, int y)
{
	CWnd *pWnd;
	pWnd = GetDlgItem(nID); 

	if (pWnd != NULL)  //�ж��Ƿ�Ϊ�գ���Ϊ�ڴ��ڴ�����ʱ��Ҳ�����OnSize���������Ǵ�ʱ�����ؼ���û�д�����pWndΪ��
	{
		CRect rec;
		int temp = 0;
		pWnd->GetWindowRect(&rec);      //��ȡ�ؼ��仯ǰ�Ĵ�С
		ScreenToClient(&rec);           //���ؼ���Сװ��λ�ڶԻ����е���������
		switch(nID)
		{
		case IDC_BTN_LOADFILES:
			rec.left = x - 85; //Original button width is 75.(85=10+75) 
			rec.right = x - 10;
			break;
		case IDC_BTN_GENRT:
			rec.left = x - 85;
			rec.right = x - 10;
			break;
		case IDC_BTN_CLR:
			rec.left = x - 85;
			rec.right = x - 10;
			break;
		case IDC_ET_FILESPATH:
			rec.right = x - 116;
			break;
		case IDC_LT_FILES:
			rec.bottom = y - 10;
			rec.right = x - 116;
			break;
		default:
			break;
		}
		pWnd->MoveWindow(rec);         //�����ؼ�
	}
}

void CThinking2Dlg::AdjustListColun()
{

}

#define MAXFILENAME  8192  //128*64
void CThinking2Dlg::OnBnClickedBtnLoadfiles()
{
	CString strpath;
	CEdit* pedit = (CEdit*)GetDlgItem(IDC_ET_FILESPATH);
	pedit->GetWindowText(strpath);

	m_filelist.clear();

	//Get summary files name list
	if (!strpath.IsEmpty())
	{
		GetPathFiles(strpath, m_filelist);
	}
	else
	{
		CFileDialog loadfiledlg(TRUE, NULL, NULL, OFN_ALLOWMULTISELECT, 
			_T("Summary files(*.csv; *.txt)|*.csv; *.txt|ACCO files(*.csv)|*.csv|Eagle files(*.txt)|*.txt||"), 
			NULL);

		DWORD maxfile = MAXFILENAME;
		loadfiledlg.m_ofn.nMaxFile = maxfile;

		TCHAR* pc = new TCHAR[maxfile];
		loadfiledlg.m_ofn.lpstrFile = pc;
		loadfiledlg.m_ofn.lpstrFile[0] = NULL;

		if (IDOK != loadfiledlg.DoModal())
		{
			return;
		}

		if (CommDlgExtendedError() == FNERR_BUFFERTOOSMALL)
		{
			AfxMessageBox(_T("Buffer too small!"));

			delete []pc;

			return;
		}

		CString temp = loadfiledlg.GetPathName();
		pedit->SetWindowText(temp);

		POSITION pos = loadfiledlg.GetStartPosition();

		while (pos != NULL)
		{
			temp = loadfiledlg.GetNextPathName(pos);
			m_filelist.push_back(temp);
		}

		delete []pc;
	}

	
	TCHAR szBuff[4] = {0};
	TCHAR szBuff1[8] = {0};

	vector<int> res_listres1;
	vector<int> res_listres2;
	vector<int> res_listres3;

	int nIndex = 0;
	int nfindpos = 0;
	char filetype1 = 'A';  //ACCO or Eagle

	m_listFiles.DeleteAllItems();

	for (vector<CString>::iterator i=m_filelist.begin(); i!=m_filelist.end(); i++)
	{
		//Check file type, ACCO or Eagle
		if (-1 != (*i).Find(_T(".csv")))
		{
			filetype1 = 'B';  //ACCO file
		}
		else
		{
			filetype1 = 'A';  //Eagle file
		}

		//Check FT or RT file
		nfindpos = (*i).Find(_T("RT"));
		if (-1 != nfindpos)
		{
			TCHAR datax = (*i).GetAt(nfindpos+2);
			if (datax == _T('1'))
			{
				res_listres1.push_back(nIndex);
			}
			else if(datax == _T('2'))
			{
				res_listres2.push_back(nIndex);
			}
			else if (datax == _T('3'))
			{
				res_listres3.push_back(nIndex);
			}	
		}
		else
		{
			nfindpos = (*i).Find(_T("RES"));

			if (-1 != nfindpos)
			{
				TCHAR datax = (*i).GetAt(nfindpos+3);
				if (datax == _T('1'))
				{
					res_listres1.push_back(nIndex);
				}
				else if(datax == _T('2'))
				{
					res_listres2.push_back(nIndex);
				}
				else if (datax == _T('3'))
				{
					res_listres3.push_back(nIndex);
				}
			}
		}

		swprintf(szBuff, _T("%03d"), nIndex+1);
		swprintf(szBuff1, _T("%c"), filetype1);
		m_listFiles.InsertItem(nIndex, szBuff, 0);
		m_listFiles.SetItemText(nIndex, 1, szBuff1);
		memset(szBuff1, 0 ,4);
		m_listFiles.SetItemText(nIndex++, 2, (*i));
	}

	if (!res_listres3.empty())
	{
		CString filetype;
		for (vector<int>::iterator i=res_listres3.begin(); i!=res_listres3.end(); i++)
		{
			filetype = m_listFiles.GetItemText((*i), 1);
			m_listFiles.SetItemText((*i), 1, filetype + _T("RTX"));
		}

		for (vector<int>::iterator j=res_listres2.begin(); j!=res_listres2.end(); j++)
		{
			filetype = m_listFiles.GetItemText((*j), 1);
			m_listFiles.SetItemText((*j), 1, filetype + _T("RT"));
		}

		for (vector<int>::iterator k=res_listres1.begin(); k!=res_listres1.end(); k++)
		{
			filetype = m_listFiles.GetItemText((*k), 1);
			m_listFiles.SetItemText((*k), 1, filetype + _T("RT"));
		}
	}
	else if (!res_listres2.empty())
	{
		CString filetype;
		for (vector<int>::iterator i=res_listres2.begin(); i!=res_listres2.end(); i++)
		{
			filetype = m_listFiles.GetItemText((*i), 1);
			m_listFiles.SetItemText((*i), 1, filetype + _T("RTX"));
		}

		for (vector<int>::iterator j=res_listres1.begin(); j!=res_listres1.end(); j++)
		{
			filetype = m_listFiles.GetItemText((*j), 1);
			m_listFiles.SetItemText((*j), 1, filetype + _T("RT"));
		}
	}
	else if (!res_listres1.empty())
	{
		CString filetype;
		for (vector<int>::iterator i=res_listres1.begin(); i!=res_listres1.end(); i++)
		{
			filetype = m_listFiles.GetItemText((*i), 1);
			m_listFiles.SetItemText((*i), 1, filetype + _T("RTX"));
		}
	}

	res_listres1.clear();
	res_listres2.clear();
	res_listres3.clear();
}


void CThinking2Dlg::OnBnClickedBtnGenrt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_listFiles.GetItemCount() <= 0)
	{
		return;
	}

	CButton* pbtn1 = (CButton*)GetDlgItem(IDC_BTN_LOADFILES);
	CButton* pbtn2 = (CButton*)GetDlgItem(IDC_BTN_GENRT);
	CEdit* pedit = (CEdit*)GetDlgItem(IDC_ET_FILESPATH);

	pbtn1->EnableWindow(FALSE);
	pedit->EnableWindow(FALSE);


	pbtn2->SetWindowText(_T("Cancel"));
	//m_CSummary.StartFilesMerge();

	m_hThread = (HANDLE)CreateThread(NULL, 0, ThreadProc, this, 0, NULL);
	CloseHandle(m_hThread);


	/*
	int index = m_listFiles.GetItemCount();
	STSignFileName item_filename;

	CString temp;
	m_pCSummary->ClearSumyList();
	for (int i=0; i<index; i++)
	{
		temp = m_listFiles.GetItemText(i,1);
		//WideCharToMultiByte();
#ifdef _UNICODE
		wcsncpy(item_filename.filename, (LPTSTR)(LPCTSTR)temp, sizeof(item_filename.filename)/sizeof(TCHAR));
#else 
		strncpy(item_filename.filename, (LPSTR)(LPCTSTR)temp, sizeof(item_filename.filename)/sizeof(TCHAR));
#endif
		if (m_pCSummary != NULL)
		{
			m_pCSummary->PushFileList(item_filename);
		}
	}

	m_hThread = (HANDLE)CreateThread(NULL, 0, ThreadProc, this, 0, NULL);
	CloseHandle(m_hThread);
	*/
}


void CThinking2Dlg::OnBnClickedBtnClr()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CEdit* pedit = (CEdit*)GetDlgItem(IDC_ET_FILESPATH);

	m_bMergeSuccess = false;

	m_testx.clear();
	m_totalsumy.clear();
	m_res1sumy.clear();
	m_vec_summary.clear();
	m_vec_summary1.clear();
	m_restotal.clear();
	//
	m_listFiles.DeleteAllItems();
	//ASSERT(m_listFiles.GetItemCount() == 0);
	pedit->SetSel(0, -1);
	pedit->Clear();
}


DWORD WINAPI CThinking2Dlg::ThreadProc(LPVOID lpParam)
{
	CThinking2Dlg* pDlg = (CThinking2Dlg*)lpParam;

	//Merge summary, calculate yield
	pDlg->DisposeWorkFlow();
	//Save merge file
	pDlg->SaveMergeResult();

	::SendMessage(pDlg->m_hWnd, WM_DISPOSE_END, (WPARAM) 0, (LPARAM) 0);

	return 0;
}


DWORD WINAPI CThinking2Dlg::DisposeWorkFlow()
{
	//m_pCSummary->ClearSumyList();
	//Sleep(100);
	//m_pCSummary->DisposeFilesList();
	//m_stResult = m_pCSummary->GetSumryRult();



	if (m_bMergeSuccess)
	{
		return 0;
	}


	m_sumyitems.clear();

	CFile dispfile;
	CString filepath;
	CString markstr;

	int flag_x = 0;
	DWORD file_bytes = 0;

	for (int i=0; i<m_listFiles.GetItemCount(); i++)
	{
		markstr = m_listFiles.GetItemText(i,1);
		filepath = m_listFiles.GetItemText(i,2);

		if (dispfile.Open(filepath, CFile::modeRead|CFile::shareDenyWrite))
		{
			file_bytes = dispfile.GetLength();
			if (file_bytes > 0 && file_bytes < 400*1024)
			{
				string str;
				char *pchar = new char[file_bytes];
				if (pchar != NULL)
				{
					dispfile.Read(pchar,file_bytes);
					str = pchar;
					delete [] pchar;
					pchar = NULL;
				}

				if (markstr.GetAt(0) == _T('A'))
				{
					if (i == 0)
					{
						flag_x = MapSummyEagle(str);
					}


					if (flag_x != -1)
					{
						if (flag_x == 1)
						{
							GetBinCountCTA(str);
						}
						else
						{
							GetBinCountEagle(str);
						}
					}

				}
				else
				{
					if (i == 0)
					{
						MapSummyACCO(str);
					}

					GetBinCountACCO(str);
				}

				//Judge RT or RTX
				if (-1 != markstr.Find(_T('R')))
				{

					if (-1 != markstr.Find(_T('X')))
					{
						m_vec_summary1.push_back(m_sumyitems);
					}
					else
					{
						m_restotal.totalbin1 += m_sumyitems.totalbin1;
					}
				}
				else
				{
					m_vec_summary.push_back(m_sumyitems);
				}
			}
		}

		dispfile.Close();
	}

	// Calculate
	for (vector<STSummary>::iterator i=m_vec_summary.begin(); i!=m_vec_summary.end(); i++)
	{
		m_totalsumy = m_totalsumy + (*i);
	}

	for (vector<STSummary>::iterator i=m_vec_summary1.begin(); i!=m_vec_summary1.end(); i++)
	{
		m_res1sumy = m_res1sumy + (*i);
	}
	
	m_bMergeSuccess = true;

	return 1;
}


void CThinking2Dlg::SaveMergeResult()
{
	CString fileName = _T("mergesummary");

//	//Unable
//	if (strlen(m_testx.lotid) > 0)
//	{
//		TCHAR tempx[128] = {0};
//#ifdef _UNICODE
//		swprintf(tempx, _T("%s_summary.csv"), m_testx.lotid);
//#else 
//		sprintf(tempx, _T("%s_summary.csv"), m_testx.lotid);
//#endif
//
//		fileName = tempx;
//	}
//	//

	CString dirpath;
	CEdit* pedit = (CEdit*)GetDlgItem(IDC_ET_FILESPATH);
	pedit->GetWindowText(dirpath);

	CFileDialog saveDlg(FALSE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Merge summary file(*.csv)|*.csv||"), NULL);

	saveDlg.m_ofn.nMaxFile = 1024;
	saveDlg.m_ofn.lpstrFile = fileName.GetBuffer(1024);

	if (!dirpath.IsEmpty())
	{
		dirpath = dirpath + _T("\\");
		saveDlg.m_ofn.lpstrInitialDir = dirpath;
	}

	if (IDOK == saveDlg.DoModal())
	{
		CString filePath;
		filePath = saveDlg.GetPathName() + _T(".csv");

		CFile writefile;
		if (writefile.Open(filePath, CFile::modeCreate|CFile::modeNoTruncate|CFile::modeWrite|CFile::shareDenyWrite))
		{
			char itemx[256] = {0};
			double yield = 0.0;
			double yieldloss = 0.0;

			STYield resultx;

			resultx.totalqtys = m_totalsumy.totalqtys;
			resultx.totalbin1 = m_totalsumy.totalbin1 + m_restotal.totalbin1 + m_res1sumy.totalbin1;
			resultx.totalfail = m_totalsumy.totalfail - m_restotal.totalbin1 - m_res1sumy.totalbin1;

			if (resultx.totalfail < 0)
			{
				resultx.totalfail = m_res1sumy.totalfail;
			}

			//
			if (resultx.totalqtys > 0)
			{
				yield = 100.0 * resultx.totalbin1 / resultx.totalqtys;
				yieldloss = 100.0 * resultx.totalfail/ resultx.totalqtys;
			}

			//Basic Info
			sprintf(itemx,"Lot#:       ,%s\r\nDevice ID:  , \r\nProgram:    ,%s\r\n", m_testx.lotid, m_testx.prgname);
			writefile.Write(itemx, strlen(itemx));
			writefile.Write("\r\n", strlen("\r\n"));
			memset(itemx, 0, 256);

			//Yield Info
			sprintf(itemx,"Total:      ,%12d\r\nPass:       ,%12d,  %.4f%%\r\nFail:       ,%12d,  %.4f%%\r\n", resultx.totalqtys, resultx.totalbin1, yield, resultx.totalfail, yieldloss);
			writefile.Write(itemx, strlen(itemx));
			writefile.Write("\r\n", strlen("\r\n"));
			memset(itemx, 0, 256);

			sprintf(itemx,"Bin#: ,Bin Summary:          ,FT Total:   ,         ,RT Total:           ,\r\n");
			writefile.Write(itemx, strlen(itemx));
			memset(itemx, 0, 256);


			double failrate = 0.0;
			double failrate_res = 0.0;

			m_res1sumy.bincount[0] = m_restotal.totalbin1 + m_res1sumy.totalbin1;

			for (int i=0; i<m_testx.totalsubitems; i++)
			{
				if (m_totalsumy.totalqtys > 0)
				{
					failrate = 100.0 * m_totalsumy.bincount[i] / m_totalsumy.totalqtys;
					failrate_res = 100.0 * m_res1sumy.bincount[i]/ m_totalsumy.totalqtys;
				} 

				sprintf(itemx,"%s,%s,%12d,    %.2f%%,        %12d,    %.2f%%",m_testx.sbinnum[i],m_testx.itemname[i],m_totalsumy.bincount[i], failrate, m_res1sumy.bincount[i], failrate_res);
				writefile.Write(itemx, strlen(itemx));
				writefile.Write("\r\n", strlen("\r\n"));
				memset(itemx, 0, 256);
			}

			writefile.Close();
		}
	}

	fileName.ReleaseBuffer();
}


LRESULT CThinking2Dlg::DisposeEnd(WPARAM wParam, LPARAM lParam)
{
	CButton* pbtn1 = (CButton*)GetDlgItem(IDC_BTN_LOADFILES);
	CButton* pbtn2 = (CButton*)GetDlgItem(IDC_BTN_GENRT);
	CEdit* pedit = (CEdit*)GetDlgItem(IDC_ET_FILESPATH);

	pbtn1->EnableWindow(TRUE);
	pedit->EnableWindow(TRUE);

	pbtn2->SetWindowText(_T("Summary"));

	return 0;
}

//Relate to Eagle
int CThinking2Dlg::MapSummyEagle(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;
	
	char tempx[64] = {0};

	// Eagle or CTA8280
	if (-1 != str.find("CTA8280", 0))
	{
/*
		//Get program name
		section0 = str.find("ProgramName", 0);
		section1 = str.find("\r\n", section0);
		//Get lot#
		section2 = str.find("LotID", section1);
		section3 = str.find("\r\n", section2);

		//Get program name
		if (section0 != -1)
		{
			str.copy(tempx, section1-section0-strlen("ProgramName"), section0+strlen("ProgramName") + 1);
			sprintf_s(m_testx.prgname, 64, tempx);
			memset(tempx, 0, 64);
		}

		//Get lot#
		if (section2 != -1)
		{
			str.copy(tempx, section3-section2-strlen("LotID"), section2+strlen("LotID") + 1);
			sprintf_s(m_testx.lotid, 64, tempx);
			memset(tempx, 0, 64);
		}
*/
		section0 = str.find("[BININFO]", 0);
		DWORD end_pos = str.find("[HARDWAREBIN]", section0);

		if ((section0 == -1) || (end_pos == -1))
		{
			return -1;
		}

		int item_index = 0;

		section1 = str.find("\r\n", section0); //Behind
		while (section1 + 15 < end_pos)
		{
			//section1 = str.find("\r\n", section0+1); //Behind
			//Bin#
			//str.copy(tempx, 30, section1+2);
			//sprintf_s(m_testx.sbinnum[item_index], 32, tempx);
			//memset(tempx, 0, 64);

			//Bin Description
			str.copy(tempx, 30, section1+2);
			sprintf(m_testx.itemname[item_index++], tempx);
			memset(tempx, 0, 64);

			section1 = str.find("\r\n", section1+1); //Behind
		}

		m_testx.totalsubitems = item_index;

		m_testx.bSuccess = true;

		return 1;
	}

	//
	//Get program name
	section0 = str.find("Test Name:", 0);
	section1 = str.find("\r\n", section0);
	//Get lot#
	section2 = str.find("Report for Lot:", section1);
	section3 = str.find("\r\n", section2);

	//if ((section0 == -1) || (section2 == -1))
	//{
	//	return -1;
	//}

	//Get program name
	if (section0 != -1)
	{
		str.copy(tempx, section1-section0-strlen("Test Name:"), section0+strlen("Test Name:") + 1);
		sprintf_s(m_testx.prgname, 64, tempx);
		memset(tempx, 0, 64);
	}

	//Get lot#
	if (section2 != -1)
	{
		str.copy(tempx, section3-section2-strlen("Report for Lot:"), section2+strlen("Report for Lot:") + 1);
		sprintf_s(m_testx.lotid, 64, tempx);
		memset(tempx, 0, 64);
	}

	section0 = str.find(" Bin# ", 0);
	section1 = str.find("Bin Description", section0);
	section2 = str.find("Bin Count", section1);
	DWORD end_pos = str.find("Hdwr", 0);

	if ((section0 == -1) || (section1 == -1) || (section2 == -1))
	{
		return -1;
	}

	int binname_secx_pos = section1 - section0;
	m_testx.offsetX = section2 - section0;
	if (m_testx.offsetX < 0)
	{
		return 0;
	}

	int item_index = 0;

	section0 = str.find("\r\n", section2);
	section1 = str.find("\r\n", section0+1); //Front

	while (section1+10 < end_pos)
	{
		section0 = str.find("\r\n", section1 + 1); //Behind
		//Bin#
		str.copy(tempx, 6, section1+2);
		sprintf_s(m_testx.sbinnum[item_index], 32, tempx);
		memset(tempx, 0, 64);

		//Bin Description
		str.copy(tempx, m_testx.offsetX - binname_secx_pos, section1 + 2 + binname_secx_pos);
		//sprintf_s(m_testx.itemname[item_index++], 32, secx);
		sprintf(m_testx.itemname[item_index++], tempx);
		memset(tempx, 0, 64);

		section1 = section0;
	}

	m_testx.totalsubitems = item_index;

	m_testx.bSuccess = true;

	return 0;
}


int CThinking2Dlg::GetBinCountEagle(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;

	char secx[32] = {0};

	//Calc Total, Passed and Failed Position
	section0 = str.find("Tested", 0);  //Get start flag
	if (section0 == -1)
	{
		return -1;
	}

	section1 = str.find("\r\n", section0);
	section0 = str.find("\r\n", section1 + 1);
	section1 = str.find('|', section0);
	section2 = str.find('|', section1 + 1);
	section3 = str.find('|', section2 + 1);

	if ((section1 == -1) || (section2 == -1) || (section3 == -1))
	{
		return -1;
	}

	//Total Tested
	str.copy(secx, section1 -section0 - 2, section0 + 2);
	m_sumyitems.totalqtys = atoi(secx);
	memset(secx, 0, 32);

	//Total Passed
	str.copy(secx, section2 - section1, section1 + 1);
	m_sumyitems.totalbin1 = atoi(secx);
	memset(secx, 0, 32);

	//Total Failed
	str.copy(secx, section3 - section2, section2 + 1);
	m_sumyitems.totalfail = atoi(secx);
	memset(secx, 0, 32);

	section0 = str.find(" Bin# ", section3);
	section1 = str.find("Bin Count", section0);

	if ((section0 == -1) || (section1 == -1))
	{
		return -1;
	}

	int pos4 = section1 - section0;  //Bin Count Section Position

	section0 = str.find("\r\n", section1);
	section1 = str.find("\r\n", section0 + 1);  //SBin Description Info End

	//Start SBin Item
	for(int index=0; index<m_testx.totalsubitems; index++)
	{
		str.copy(secx, 9, section1 + 2 + pos4);
		m_sumyitems.bincount[index] = atoi(secx);
		memset(secx, 0, 32);
		section1 = str.find("\r\n", section1 + 1);
	}

	return 0;
}


int CThinking2Dlg::GetBinCountCTA(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;

	char secx[32] = {0};

	//Calc Total, Passed and Failed Position
	section0 = str.find("[SUMMARY]", 0);  //Get start flag
	section1 = str.find("\r\n", section0);
	section2 = str.find("\r\n", section1 + 1);
	section3 = str.find("\r\n", section2 + 1);
	if (section0 == -1)
	{
		return -1;
	}

	
	//Total Tested
	str.copy(secx, 10, section1 + 2 + 30);
	m_sumyitems.totalqtys = atoi(secx);
	memset(secx, 0, 32);


	//Total Passed
	str.copy(secx, 10, section2 + 2 + 30);
	m_sumyitems.totalbin1 = atoi(secx);
	memset(secx, 0, 32);

	//Total Failed
	str.copy(secx, 10, section3 + 2 + 30);
	m_sumyitems.totalfail = atoi(secx);
	memset(secx, 0, 32);

	section0 = str.find("[BININFO]", section3);

	if (section0 == -1)
	{
		return -1;
	}


	//Start SBin Item
	for(int index=0; index<m_testx.totalsubitems; index++)
	{
		section1 = str.find("\r\n", section0 + 1);
		str.copy(secx, 10, section1 + 2 + 30);
		m_sumyitems.bincount[index] = atoi(secx);
		memset(secx, 0, 32);

		section0 = section1;
	}

	return 0;
}


//Relate to ACCO
int CThinking2Dlg::MapSummyACCO(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;
	
	char buffx[64] = {0};
	//Get program name
	section0 = str.find("STS8200 StationA", 0);
	if (section0 == -1)
	{
		return -1;
	}

	section0 = str.find("Program:", section0);
	section1 = str.find("\r\n", section0);
	//Get lot#
	section2 = str.find("Lot", section1);
	section3 = str.find("\r\n", section2);

	if ((section0 == -1) || (section2 == -1))
	{
		return -1;
	}

	//Get program name
	str.copy(buffx, 22, section1-22);
	string temp = buffx;
	sprintf_s(m_testx.prgname, 64, buffx);
	memset(buffx, 0, 64);

	//Get lot#
	str.copy(buffx, section3-section2-strlen("Lot")-4, section2+strlen("Lot")+4);
	sprintf_s(m_testx.lotid, 64, buffx);
	memset(buffx, 0, 64);

	section0 = str.find("Site:", section3);  //All Site location
	DWORD end_pos = str.find("Site:", section0+1);

	if ((section0 == -1) || (end_pos == -1))
	{
		return -1;
	}

	//Start SBin Item
	int item_index = 0;

	while (section1 < end_pos)
	{
		section1 = str.find("SBin[", section0);

		//Bin#
		str.copy(buffx, 20, section1);
		sprintf_s(m_testx.sbinnum[item_index], 32, buffx);
		memset(buffx, 0, 64);

		//Bin Description
		str.copy(buffx, 20, section1+21);
		sprintf(m_testx.itemname[item_index++], buffx);
		memset(buffx, 0, 64);

		section0 = section1 + 1;
	}

	m_testx.totalsubitems = item_index - 1;

	m_testx.bSuccess = true;

	return 0;
}

int CThinking2Dlg::GetBinCountACCO(string &str)
{
	if (!m_testx.bSuccess)
	{
		return -1;
	}

	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	char buffx[32] = {0};

	//Get start flag
	section0 = str.find("Total:", 0);
	section1 = str.find("Pass:", section0);
	section2 = str.find("Fail:", section1);

	//Total Tested
	str.copy(buffx, 20, section0+21);
	m_sumyitems.totalqtys = atoi(buffx);
	memset(buffx, 0, 32);

	//Total Passed
	str.copy(buffx, 20, section1+21);
	m_sumyitems.totalbin1 = atoi(buffx);
	memset(buffx, 0, 32);

	//Total Failed
	str.copy(buffx, 20, section2+21);
	m_sumyitems.totalfail = atoi(buffx);
	memset(buffx, 0, 32);

	for(int index=0; index<m_testx.totalsubitems; index++)
	{
		section0 = str.find("SBin[", section2);

		str.copy(buffx, 20, section0+42);
		m_sumyitems.bincount[index] = atoi(buffx);
		memset(buffx, 0, 32);

		section2 = section0 + 1;
	}

	return 0;
}

//int CThinking2Dlg::CheckFileType(const CString str)
//{
//	return 0;
//}

void CThinking2Dlg::GetPathFiles(CString filepath, vector<CString> &filelist)
{
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;

	CString strx;

	if (m_bFileType)
	{
		strx = 	filepath + _T("\\*.csv");
	}
	else
	{
		strx = 	filepath + _T("\\*.txt");
	}

	hFind = FindFirstFile(strx, &FindFileData);

	if (INVALID_HANDLE_VALUE != hFind) 
	{
		do
		{
			if (FindFileData.dwFileAttributes != FILE_ATTRIBUTE_DIRECTORY)
			{
				filelist.push_back(filepath + _T("\\") + FindFileData.cFileName);
			}
		}while(FindNextFile(hFind, &FindFileData));
	}

	FindClose(hFind);
}

void CThinking2Dlg::OnBnClickedRadioEagle()
{
	m_bFileType = false;
}


void CThinking2Dlg::OnBnClickedRadioAcco()
{
	m_bFileType = true;
}


void CThinking2Dlg::OnHdnItemclickLtFiles(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMHEADER phdr = reinterpret_cast<LPNMHEADER>(pNMHDR);

	CListCtrl* pListCtrl = (CListCtrl*) GetDlgItem(IDC_LT_FILES);
	ASSERT(pListCtrl != NULL);

	if (pListCtrl->GetItemCount() <= 0)
	{
		*pResult = 0;
		return;
	}

	if (phdr->iItem == 2)
	{
		POSITION pos = pListCtrl->GetFirstSelectedItemPosition();
		if (NULL != pos)
		{
			int nItem = pListCtrl->GetNextSelectedItem(pos);
			pListCtrl->DeleteItem(nItem);
		}
	}

	*pResult = 0;
}
