// Thinking2Dlg.h : ͷ�ļ�
//
#pragma once

//#include "CSummary.h"
#include <string>
#include <vector>

using std::string;
using std::vector;

struct STMapSubItemX
{
	char deviceid[32];
	char lotid[64];
	char prgname[64];

	char sbinnum[256][32];
	char itemname[256][64];

	unsigned int totalsubitems;
	//bool bABflag;  //Only for Eagle summary, Eagle tester use AB sides.
	unsigned int offsetX;  //Only for Eagle summary.

	bool bSuccess;
	
	STMapSubItemX()
	{
		clear();
	}

	void clear()
	{
		totalsubitems  = 0;
		offsetX = 0;
		//bABflag = false;
		bSuccess = false;
		memset(deviceid, 0, sizeof(deviceid));
		memset(lotid, 0, sizeof(lotid));
		memset(prgname, 0, sizeof(prgname));
		memset(sbinnum, 0, sizeof(sbinnum));
		memset(itemname, 0, sizeof(itemname));
	}
};


struct STSummary
{
	DWORD totalqtys;
	DWORD totalbin1;
	DWORD totalfail;
	DWORD bincount[256];

	STSummary()
	{
		clear();
	}

	void clear()
	{
		totalqtys = 0;
		totalbin1= 0;
		totalfail= 0;
		for (int i=0; i<256; i++)
		{
			bincount[i] = 0;
		}
	}

	STSummary operator=(const STSummary &summary_obj)
	{
		totalqtys = summary_obj.totalqtys;
		totalbin1 = summary_obj.totalbin1;
		totalfail = summary_obj.totalfail;

		for (int i=0; i<256; i++)
		{
			bincount[i] = summary_obj.bincount[i];
		}

		return *this;
	}

	STSummary operator+(const STSummary &addend)
	{
		STSummary addfirst;
		addfirst.totalqtys = totalqtys + addend.totalqtys;
		addfirst.totalbin1 = totalbin1 + addend.totalbin1;
		addfirst.totalfail = totalfail + addend.totalfail;

		for (int i=0; i<256; i++)
		{
			addfirst.bincount[i] = bincount[i] + addend.bincount[i];
		}

		return addfirst;
	}
};


struct STYield
{
	DWORD totalqtys;
	DWORD totalbin1;
	DWORD totalfail;

	double yield;
	double yieldloss;

	STYield()
	{
		clear();
	}

	void clear()
	{
		totalqtys = 0;
		totalbin1= 0;
		totalfail= 0;

		yield = 0.0;
		yieldloss = 0.0;
	}
};


#define WM_DISPOSE_END		        WM_USER+100    //user-defined message: dispose files list finished

// CThinking2Dlg �Ի���
class CThinking2Dlg : public CDialog
{
// ����
public:
	CThinking2Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_THINKING2_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedBtnLoadfiles();
	afx_msg void OnBnClickedBtnGenrt();
	afx_msg void OnBnClickedBtnClr();
	afx_msg void OnBnClickedRadioEagle();
	afx_msg void OnBnClickedRadioAcco();
	afx_msg void OnHdnItemclickLtFiles(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
public:
	//UI
	void ChangeSize(UINT nID, int x, int y);
	void AdjustListColun();

	//Work flow
	static DWORD WINAPI ThreadProc(LPVOID lpParam);
	LRESULT DisposeEnd(WPARAM wParam, LPARAM lParam);

	DWORD WINAPI DisposeFilesList();
	DWORD WINAPI DisposeWorkFlow();
	
	void SaveMergeResult();

	//Eagle
	int MapSummyEagle(string &str);
	int GetBinCountEagle(string &str);
	//ACCO
	int MapSummyACCO(string &str);
	int GetBinCountACCO(string &str);
	//CAT8200
	int GetBinCountCTA(string &str);

	//int CheckFileType(const CString str);

	void GetPathFiles(CString filepath, vector<CString> &filelist);

private:
	STSummary m_sumyitems;
	bool m_bRESSummary;

public:
	CRect m_rect;
	CFont m_fontEdit;
	CListCtrl m_listFiles;

	HANDLE m_hThread;
	//CSummary *m_pCSummary;
	//STSummary m_stResult;
	//bool m_bLoadOk;    //
	bool m_bFileError;
	bool m_bMergeSuccess;
	bool m_bFileType;
	
	STMapSubItemX m_testx;

	STSummary m_totalsumy;
	STSummary m_res1sumy;
	
	vector<STSummary> m_vec_summary; 
	vector<STSummary> m_vec_summary1;  //RES1 summary

	STYield m_restotal;

	vector<CString> m_filelist;

};
