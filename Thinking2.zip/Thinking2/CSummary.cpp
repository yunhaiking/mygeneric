
#include "stdafx.h"
#include "CSummary.h"

CSummary::CSummary()
{
	
}

CSummary::~CSummary()
{
	
}

bool CSummary::GetFilesList(const STSignFileName filelist[], int itotalfiles)
{
	if (filelist == NULL || itotalfiles<=0)
	{
		return false;
	}

	m_vecFilesList.clear();

	for (int i=0; i<itotalfiles; i++)
	{
		m_vecFilesList.push_back(filelist[i]);
	}

	return true;
}

bool CSummary::PushFileList(const STSignFileName filex)
{
	m_vecFilesList.push_back(filex);
	return true;
}

DWORD CSummary::DisposeFilesList()
{
	int index = m_vecFilesList.size();
	CString temp;
	//CStdioFile dispfile;
	CFile dispfile;
	char buffer[1024] = {0};
	//m_pstsreport = new STSummary[index];
	m_vec_summary.clear();
	m_totalsumy.clear();
	STSignFileName runstfn;
	for (int i=0; i<index; i++)
	{
		STSummary resultx;
		runstfn = m_vecFilesList[i];
		temp = runstfn.filename;
		if (dispfile.Open(temp,CFile::modeRead|CFile::shareDenyWrite))
		{
			//dispfile.Seek(400,CFile::begin);
			DWORD file_bytes = dispfile.GetLength();
			if (file_bytes > 0 && file_bytes < 102400)  // maximal file size <100KB
			{
				char *pchar = new char[file_bytes];
				if (pchar != NULL)
				{
					string str;
					dispfile.Read(pchar,file_bytes);
					str = pchar;
					delete [] pchar;
					pchar = NULL;
					ExtractItemsX(str);
					resultx = ExtractItems(str);
					m_vec_summary.push_back(resultx);
				}
			}

			dispfile.Close();
		}
	}

	for (vector<STSummary>::iterator i=m_vec_summary.begin(); i!=m_vec_summary.end(); i++)
	{
		m_totalsumy = m_totalsumy + (*i);
	}

	return 0;
}

bool CSummary::GenerateSummaryFile()
{
	return false;
}

//DWORD WINAPI CSummary::ThreadProc(LPVOID lpParam)
//{
//	CSummary* pCSy = (CSummary*)lpParam;
//	
//
//	return pCSy->DisposeFilesList();
//}

void CSummary::SaveMergeResult()
{
	CFile writefile;
	char tempx[64]={0};
	if (writefile.Open(_T("summarymergeresult.csv"),CFile::modeCreate|CFile::modeNoTruncate|CFile::modeWrite|CFile::shareDenyWrite))
	{
		sprintf_s(tempx, 64, "SBin Name      ,");//16
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "TestItems Name                 ,");//32
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "Qtys Before RES,");//16
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "Rate   ,");//8
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "Qtys After RES ,");//16
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "Rate   ,");//8
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		sprintf_s(tempx, 64, "HBinNo.,");//8
		writefile.Write(tempx, strlen(tempx));
		memset(tempx, 0, 64);
		writefile.Write("\r\n", strlen("\r\n"));
		writefile.SeekToEnd();
	}
}

STSummary& CSummary::ExtractItems(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;
	int section4 = 0;
	int section5 = 0;
	bool cont_flag = true;
	STSummary m_sumyitems;
	
	int item_index = 0;

	char tempx[64] = {0};
	section0 = str.find("Total:", 0);
	section1 = str.find(',', section0);
	str.copy(tempx, 16, section1+1);
	m_sumyitems.totalqtys = atoi(tempx);
	memset(tempx, 0, 32);

	section2 = str.find("Pass:", section1);
	section3 = str.find(',', section2);
	str.copy(tempx, 16, section3+1);
	m_sumyitems.totalbin1= atoi(tempx);
	memset(tempx, 0, 32);

	section4 = str.find("Fail:", section3);
	section5 = str.find(',', section4);
	str.copy(tempx, 16, section5+1);
	m_sumyitems.totalfail = atoi(tempx);
	memset(tempx, 0, 32);

	DWORD end_pos = str.find("Site:", 0);
	end_pos = str.find("Site:", end_pos+1);

	while (cont_flag)
	{
		section1 = str.find("SBin[", section1);
		section2 = str.find(',', section1);
		section3 = str.find(',', section2+1);
		section4 = str.find(',', section3+1);
		section5 = str.find(',', section4+1);

		section0 = section1 + section5;
		if ((section1 > end_pos) /*|| (section1 == str.npos)*/)
		{
			cont_flag = false;
			break;
		}

		char secx[32] = {0};
		str.copy(secx, section4-section3-1, section3+1);
		m_sumyitems.itemsqtys[item_index++] = atoi(secx);
		memset(secx, 0, 32);

		section1 = section5;
	}

	return m_sumyitems;
}


void CSummary::ExtractItemsX(string &str)
{
	int section0 = 0;
	int section1 = 0;
	int section2 = 0;
	int section3 = 0;
	int section4 = 0;
	int section5 = 0;
	bool cont_flag = true;
	STSummary m_sumyitems;
	
	int item_index = 0;

	char tempx[64] = {0};
	section0 = str.find("Total:", 0);
	section1 = str.find(',', section0);
	str.copy(tempx, 16, section1+1);
	m_sumyitems.totalqtys = atoi(tempx);
	memset(tempx, 0, 32);

	section2 = str.find("Pass:", section1);
	section3 = str.find(',', section2);
	str.copy(tempx, 16, section3+1);
	m_sumyitems.totalbin1= atoi(tempx);
	memset(tempx, 0, 32);

	section4 = str.find("Fail:", section3);
	section5 = str.find(',', section4);
	str.copy(tempx, 16, section5+1);
	m_sumyitems.totalfail = atoi(tempx);
	memset(tempx, 0, 32);

	DWORD end_pos = str.find("Site:", 0);
	end_pos = str.find("Site:", end_pos+1);

	while (cont_flag)
	{
		section1 = str.find("SBin[", section1);
		section2 = str.find("] ", section1);
		section3 = str.find(',', section2+1);
		section4 = str.find(',', section3+1);

		if ((section1 > end_pos) /*|| (section1 == str.npos)*/)
		{
			cont_flag = false;
			break;
		}

		char secx[16] = {0};
		str.copy(secx, section2-section1+1, section1);
		short dataleng = strlen(secx);
		memset(secx, 0, 16);

		section1 = section4;
	}

}

void CSummary::StartFilesMerge(void)
{
	if (!m_bLaunch)
		m_bLaunch = true;
}

void CSummary::ClearSumyList(void)
{
	m_vecFilesList.clear();
}


STSummary& CSummary::GetSumryRult()
{
	return m_totalsumy;
}


int CSummary::GetWorkStatus()
{
	return m_istatus;
}