#pragma once

#ifndef __CSUMMARY_H__
#define __CSUMMARY_H__
#endif

#include <string>
#include <vector>

using std::string;
using std::vector;

//Used to store names in file list.
struct STSignFileName
{
	//char filename[128];
	TCHAR filename[128];
	short filetype;
	short filesorted;
};

struct STBinItem
{
	unsigned int item_num;
	TCHAR item_name[32];
};

//Summary file itemX
struct STSummaryX
{
	TCHAR deviceid[32];
	TCHAR lotid[32];
	TCHAR prgname[32];
	STBinItem sumy_item[128];
};

//Summary file item
struct STSummary
{
	DWORD totalqtys;
	DWORD totalbin1;
	DWORD totalfail;
	DWORD itemsqtys[128];

	STSummary()
	{
		totalqtys = 0;
		totalbin1= 0;
		totalfail= 0;
		for (int i=0; i<128; i++)
		{
			itemsqtys[i] = 0;
		}
		//memset(itemsqtys, 0, 128);
	}

	void clear()
	{
		totalqtys = 0;
		totalbin1= 0;
		totalfail= 0;
		for (int i=0; i<128; i++)
		{
			itemsqtys[i] = 0;
		}
	}

	STSummary operator=(const STSummary &summary_obj)
	{
		totalqtys = summary_obj.totalqtys;
		totalbin1 = summary_obj.totalbin1;
		totalfail = summary_obj.totalfail;

		for (int i=0; i<128; i++)
		{
			itemsqtys[i] = summary_obj.itemsqtys[i];
		}

		return *this;
	}

	STSummary operator+(const STSummary &addend)
	{
		STSummary addfirst;
		addfirst.totalqtys = totalqtys + addend.totalqtys;
		addfirst.totalbin1 = totalbin1 + addend.totalbin1;
		addfirst.totalfail = totalfail + addend.totalfail;

		for (int i=0; i<128; i++)
		{
			addfirst.itemsqtys[i] = itemsqtys[i] + addend.itemsqtys[i];
		}

		return addfirst;
	}
};


enum EM_DISPOSE_STATE
{
	RESULT_OK = 0,		//Success Flag
	RESULT_FAIL,
	RESULT_WORKING,
};

class CSummary
{
public:
	CSummary();
	~CSummary();
public:
	//static DWORD WINAPI ThreadProc(LPVOID lpParam);
	DWORD DisposeFilesList();
	bool GetFilesList(const STSignFileName filelist[], int itotalfiles);
	bool PushFileList(const STSignFileName filex);
	void SaveMergeResult();

	bool GenerateSummaryFile();
	void StartFilesMerge(void);
	void ClearSumyList(void);
	STSummary& GetSumryRult();
	int  GetWorkStatus();
	void SetWorkStatus();
	

private:
	STSummary& ExtractItems(string &str);
	void ExtractItemsX(string &str);

private:
	bool m_bLaunch;
	vector<STSignFileName> m_vecFilesList;
	vector<STSummary> m_vec_summary;
	STSummary m_totalsumy;
	STSummaryX m_sumytemplate;

	int m_istatus;
};